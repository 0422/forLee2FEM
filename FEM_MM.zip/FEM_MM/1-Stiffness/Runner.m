clc
clear
% nodes coordinates for triangle element
% x = [0 0; 2 0; 1 1]; 
% nodes coordinates for quadrilateral element
x = [0 0; 1 0; 1 2; 0 2];
GPE = 4;
Stiffness(x,GPE)