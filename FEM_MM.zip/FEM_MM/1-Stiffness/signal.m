function result = signal(x)
switch x > 0
    case true
        result = 1;
    case false
        result = -1;
end
end