clc;
clear;
clf;

d1 = 1;
d2 = 1;
p = 3;
m = 4;
% element_type = 'D2TR3N'
element_type = 'D2QU4N';
R = 0.2;
% [NL, EL] = uniform_mesh(d1,d2,p,m,element_type);

[NL, EL] = void_mesh(d1,d2,p,m,R,element_type);
