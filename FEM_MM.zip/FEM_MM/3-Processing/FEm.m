clear; clc;
format long;
%%% PRE-PROCESS %%%
d1 = 1;
d2 = 1;
p = 3;
m = 4;
R = 0.2;
element_type = 'D2QU4N';

%PD: Problem Dimension
%NPE: Node per Element
%NoN: Number of Nodes
%NoE: Number of Elements
%NL: Node List [NoN*PD](Coordinates)
%EL: Element List [NoE*NPE]
%ENL: Extended Node List [NoN*(6*PD)]
%DOFs: Degrees of Freedom
%DOCs: Degrees of Constraint

BC_type = 'Extension'; % Expansion Shear
[NL, EL] = void_mesh(d1,d2,p,m,R,element_type);

%%% PROCESS %%%

[ENL, DOFs, DOCs] = assign_BC(NL, BC_type);
K = assemble_stiffness(ENL,EL,NL);
Fp = assemble_forces(ENL,NL,DOFs);
Up = assemble_displacements(ENL,NL,DOCs);

Kpu = K(1:DOFs,1:DOFs);
Kpp = K(1:DOFs,DOFs+1:DOFs+DOCs);
Kuu = K(DOFs+1:DOFs+DOCs,1:DOFs);
Kup = K(DOFs+1:DOFs+DOCs,DOFs+1:DOFs+DOCs);
Uu = Kpu\(Fp-Kpp*Up);
Fu = Kuu*Uu + Kup*Up;
ENL = update_nodes(ENL,Uu,NL,Fu);

% Node_flag = 'on';
% Element_flag = 'on';
%
% mag = 40; %magnification factor
%
% post_process(NL,EL,ENL,E,Node_flag,Element_flag,mag);