function [ENL, DOFs, DOCs] = assign_BC(NL, BC_type)
NoN = size(NL,1);   % Number of Nodes
PD = size(NL,2);    % Problem Dimension
ENL = zeros(NoN,6*PD);
ENL(:,1:PD) = NL;    % Coordinates
switch BC_type
    case 'Extension'
        for i = 1:NoN
            if ENL(i,1) == 0
                ENL(i,PD+1) = -1; % dirichlet BC x
                ENL(i,PD+2) = -1; % dirichlet BC y

                ENL(i,4*PD+1) = -0.1; % displacement x
                ENL(i,4*PD+2) = 0; % displacement y
            elseif ENL(i,1) == 1
                ENL(i,PD+1) = -1; % dirichlet BC x
                ENL(i,PD+2) = -1; % dirichlet BC y

                ENL(i,4*PD+1) = 0.1; % displacement x
                ENL(i,4*PD+2) = 0; % displacement y
            else
                ENL(i,PD+1) = 1; % nuemann BC x
                ENL(i,PD+2) = 1; % nuemann BC y

                ENL(i,4*PD+1) = 0; % displacement x
                ENL(i,4*PD+2) = 0; % displacement y
            end
        end
    case 'Expansion'
        for i = 1:NoN
            if ENL(i,1) == 0
                ENL(i,PD+1) = -1; % dirichlet BC x
                ENL(i,PD+2) = -1; % dirichlet BC y

                ENL(i,4*PD+1) = 0.1*ENL(i,1); % displacement x
                ENL(i,4*PD+2) = 0.1*ENL(i,2); % displacement y
            elseif ENL(i,1) == 1
                ENL(i,PD+1) = -1; % dirichlet BC x
                ENL(i,PD+2) = -1; % dirichlet BC y

                ENL(i,4*PD+1) = 0.1*ENL(i,1); % displacement x
                ENL(i,4*PD+2) = 0.1*ENL(i,2); % displacement y
            elseif ENL(i,2) == 0
                ENL(i,PD+1) = -1; % dirichlet BC x
                ENL(i,PD+2) = -1; % dirichlet BC y

                ENL(i,4*PD+1) = 0.1*ENL(i,1); % displacement x
                ENL(i,4*PD+2) = 0.1*ENL(i,2); % displacement y
            elseif ENL(i,2) == 1
                ENL(i,PD+1) = -1; % dirichlet BC x
                ENL(i,PD+2) = -1; % dirichlet BC y

                ENL(i,4*PD+1) = 0.1*ENL(i,1); % displacement x
                ENL(i,4*PD+2) = 0.1*ENL(i,2); % displacement y
            else
                ENL(i,PD+1) = 1;
                ENL(i,PD+2) = 1;
                ENL(i,4*PD+1) = 0;
                ENL(i,4*PD+2) = 0;
            end
        end
    case 'Shear'
        for i = 1:NoN
            if ENL(i,2) == 0
                ENL(i,PD+1) = -1; % dirichlet BC x
                ENL(i,PD+2) = -1; % dirichlet BC y

                ENL(i,4*PD+1) = 0; % displacement x
                ENL(i,4*PD+2) = 0; % displacement y
            elseif ENL(i,2) == 1
                ENL(i,PD+1) = -1; % dirichlet BC x
                ENL(i,PD+2) = -1; % dirichlet BC y

                ENL(i,4*PD+1) = 0.1; % displacement x
                ENL(i,4*PD+2) = 0; % displacement y
            else
                ENL(i,PD+1) = 1; % nuemann BC x
                ENL(i,PD+2) = 1; % nuemann BC y

                ENL(i,4*PD+1) = 0; % displacement x
                ENL(i,4*PD+2) = 0; % displacement y
            end
        end
    otherwise
end

DOFs = 0;
DOCs = 0;
for i = 1:NoN
    for j = 1:PD
        if (ENL(i,(PD+j)) == -1)
            DOCs = DOCs -1;
            ENL(i,2*PD+j) = DOCs;
        else
            DOFs = DOFs +1;
            ENL(i,2*PD+j) = DOFs;
        end
    end
end
for i = 1:NoN
    for j = 1:PD
        if(ENL(i,2*PD+j) < 0)
            ENL(i,3*PD+j) = DOFs + abs(ENL(i,2*PD+j));
        else
            ENL(i,3*PD+j) = ENL(i,2*PD+j);
        end
    end
end
DOCs = abs(DOCs);
end