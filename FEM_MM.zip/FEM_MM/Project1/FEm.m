clear; clc;
format long;
A = 0.01;
E = 10^6;

%PD: Problem Dimension
%NPE: Node per Element
%NoN: Number of Nodes
%NoE: Number of Elements
%NL: Node List [NoN*PD](Coordinates)
%EL: Element List [NoE*NPE]
%ENL: Extended Node List [NoN*(6*PD)]
%DOFs: Degrees of Freedom
%DOCs: Degrees of Constraint

NL = [0,0;1,0;0.5,1];
EL = [1,2;2,3;1,3];
[ENL, DOFs, DOCs] = assign_BC(NL);
K = assemble_stiffness(ENL,EL,NL,E,A);
Fp = assemble_forces(ENL,NL,DOFs);
Up = assemble_displacements(ENL,NL,DOCs);

Kpu = K(1:DOFs,1:DOFs);
Kpp = K(1:DOFs,DOFs+1:DOFs+DOCs);
Kuu = K(DOFs+1:DOFs+DOCs,1:DOFs);
Kup = K(DOFs+1:DOFs+DOCs,DOFs+1:DOFs+DOCs);
Uu = Kpu\(Fp-Kpp*Up);
Fu = Kuu*Uu + Kup*Up;
ENL = update_nodes(ENL,Uu,NL,Fu);

Node_flag = 'on';
Element_flag = 'on';

mag = 40; %magnification factor

post_process(NL,EL,ENL,E,Node_flag,Element_flag,mag);