elementInfo = [1, 2, 1, 2, 3;...
               2, 4, 3, 3, 4];
BCInfo = [1, 2, 2 ,1;...
          0, 0, 0, 1];
stiffnessInfo = [1, 1, 1, 1, 1];
KFull = zeros(4, 4);    % Initialize stiffness matrix
for ii = 1:5
    KFull(elementInfo(:,ii),elementInfo(:,ii)) = ...
        KFull(elementInfo(:,ii),elementInfo(:,ii)) + ...
        stiffnessInfo(ii)*[1,-1;-1,1];
end
isDirichletBC = (BCInfo(1,:) == 1);
isNeumannBC = (BCInfo(1,:) == 2);
Kuu = KFull(isNeumannBC,isNeumannBC);
Kup = KFull(isNeumannBC,isDirichletBC);
Kpu = KFull(isDirichletBC,isNeumannBC);
Kpp = KFull(isDirichletBC,isDirichletBC);
uu = BCInfo(2,isNeumannBC)';
up = BCInfo(2,isDirichletBC)';
