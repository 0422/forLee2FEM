%Node list x,y,
NL = double([0, 0, int16('D'), int16('D');
      1, 0, int16('N'), int16('N');
      2, 0, int16('N'), int16('D');
      0, 1, int16('D'), int16('D');
      1, 1, int16('N'), int16('N')]);
%Generate TempDeg
TempDeg = zeros(size(NL,1),2);
DOF = 0; DOC = 0;
for ii = 1:size(NL,1)
    for jj = 1:2
        if NL(ii,2+jj) == 'N'
            DOF = DOF + 1;
            TempDeg(ii,jj) = DOF;
        elseif NL(ii,2+jj) == 'D'
            DOC = DOC - 1;
            TempDeg(ii,jj) = DOC;
        end
    end
end
TempDeg
%Generate GlobalDeg
GlobalDeg = TempDeg;
for ii = 1:size(GlobalDeg,1)
    for jj = 1:size(GlobalDeg,2)
        if TempDeg(ii,jj) < 0
            GlobalDeg(ii,jj) = abs(TempDeg(ii,jj)) + DOF;
        end
    end
end
GlobalDeg
Disp = [0,0;nan,nan;nan,0;0,0;nan,nan];
Force = [nan,nan;0,-2;1,nan;nan,nan;-6*sind(30),6*cosd(30)];
ENL = [NL,TempDeg,Disp,Force];
%Element list
EL = [1,5;2,5;2,3;3,5;4,5;1,2];
%E:elastic modul A:area
E = 10*ones(size(EL,1),1);
A = 1*ones(size(EL,1),1);
%Assemble the stiffness matrix
KGlobal = zeros(2*size(NL,1));
for ii = 1:size(EL,1)
    globalIdx = GlobalDeg(EL(ii,:),:);
    locCoor = NL(EL(ii,:),[1,2]);
    L = sqrt((locCoor(2,2)-locCoor(1,2))^2 + (locCoor(2,1)-locCoor(1,1))^2);
    sTheta = (locCoor(2,2)-locCoor(1,2))/L;
    cTheta = (locCoor(2,1)-locCoor(1,1))/L;
    KLocal = [cTheta^2, sTheta*cTheta, -cTheta^2, -cTheta*sTheta;...
              cTheta*sTheta, sTheta^2, -cTheta*sTheta, -sTheta^2;...
             -cTheta^2, -cTheta*sTheta, cTheta^2, cTheta*sTheta;...
             -cTheta*sTheta, -sTheta^2, cTheta*sTheta, sTheta^2];
    KGlobal(globalIdx,globalIdx) = KGlobal(globalIdx,globalIdx)+KLocal;
end